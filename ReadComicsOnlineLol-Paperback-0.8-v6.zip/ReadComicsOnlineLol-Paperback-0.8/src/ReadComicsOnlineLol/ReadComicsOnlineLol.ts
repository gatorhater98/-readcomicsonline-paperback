import {
  PagedResults,
  SearchRequest,
  SearchResultsProviding,
  Source,
  SourceInfo,
  SourceIntents,
  ContentRating,
} from '@paperback/types'

export const ReadComicsOnlineLolInfo: SourceInfo = {
  version: '0.1',
  name: 'ReadComicsOnline.lol',
  description: 'Experimental Western comics source',
  author: 'gatorhater98',
  authorWebsite: 'https://github.com/gatorhater98',
  icon: 'icon.png',
  contentRating: ContentRating.MATURE,
  websiteBaseURL: 'https://readcomicsonline.lol',
  intents: SourceIntents.MANGA_CHAPTERS,
  sourceTags: [],
}

export class ReadComicsOnlineLol extends Source implements SearchResultsProviding {
  async getSearchResults(_query: SearchRequest, _metadata: any): Promise<PagedResults> {
    return {
      results: [],
      metadata: undefined,
    }
  }
}
