# ReadComicsOnline.lol — Paperback 0.8 V3 build

This is an experimental first-pass source targeting Paperback 0.8.x.

Target site:
https://readcomicsonline.lol/

Known test path:
- Series: /comic/Absolute-Batman
- Issue: /comic/Absolute-Batman/23
- Reader CDN pattern: cdn.readcomicsonline.lol/pages/.../p001.webp

## Build

    npm install
    npm run bundle

## Local serving

    npm run serve

This is an experimental build. Search selectors/endpoints may need adjustment
after the first live Paperback test.
