import {
  Chapter,
  ChapterDetails,
  ChapterProviding,
  ContentRating,
  MangaProviding,
  PagedResults,
  PartialSourceManga,
  SearchRequest,
  SearchResultsProviding,
  Source,
  SourceInfo,
  SourceIntents,
  SourceManga,
} from '@paperback/types'
import * as cheerio from 'cheerio'

const DOMAIN = 'https://readcomicsonline.lol'

export const ReadComicsOnlineLolInfo: SourceInfo = {
  version: '0.1',
  name: 'ReadComicsOnline.lol',
  description: 'Experimental Western comics source',
  author: 'gatorhater98',
  authorWebsite: 'https://github.com/gatorhater98',
  icon: 'icon.png',
  contentRating: ContentRating.MATURE,
  websiteBaseURL: DOMAIN,
  intents: SourceIntents.MANGA_CHAPTERS,
  sourceTags: [],
}

export class ReadComicsOnlineLol extends Source
  implements ChapterProviding, MangaProviding, SearchResultsProviding {

  requestManager = App.createRequestManager({
    requestsPerSecond: 3,
    requestTimeout: 15000,
    interceptor: {
      interceptRequest: async (request) => {
        request.headers = {
          ...(request.headers ?? {}),
          referer: `${DOMAIN}/`,
          accept: 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        }
        request.url = request.url.replace(/^http:/, 'https:')
        return request
      },
    },
  })

  private async get(url: string): Promise<string> {
    const response = await this.requestManager.schedule(
      App.createRequest({ url, method: 'GET' }), 1
    )
    return response.data as string
  }

  async getSearchResults(query: SearchRequest, _metadata: any): Promise<PagedResults> {
    const title = (query.title ?? '').trim()
    if (!title) {
      return App.createPagedResults({ results: [], metadata: undefined })
    }

    const q = encodeURIComponent(title)
    const candidates = [
      `${DOMAIN}/search?q=${q}`,
      `${DOMAIN}/search?query=${q}`,
      `${DOMAIN}/?s=${q}`,
    ]

    const results: PartialSourceManga[] = []

    for (const url of candidates) {
      try {
        const $ = cheerio.load(await this.get(url))

        $('a[href*="/comic/"]').each((_, el) => {
          const a = $(el)
          const href = a.attr('href') ?? ''
          const match = href.match(/\/comic\/([^/?#]+)\/?$/)
          if (!match) return

          const mangaId = match[1]
          const image =
            a.find('img').attr('src') ??
            a.find('img').attr('data-src') ??
            ''

          const text = a.text().replace(/\s+/g, ' ').trim()
          const alt = a.find('img').attr('alt') ?? ''
          const mangaTitle = text || alt || mangaId.replace(/-/g, ' ')

          if (
            mangaTitle.toLowerCase().includes(title.toLowerCase()) &&
            !results.some((x) => x.mangaId === mangaId)
          ) {
            results.push(App.createPartialSourceManga({
              mangaId,
              image,
              title: mangaTitle,
            }))
          }
        })

        if (results.length > 0) break
      } catch {
        // Try the next candidate endpoint.
      }
    }

    return App.createPagedResults({
      results,
      metadata: undefined,
    })
  }

  async getMangaDetails(mangaId: string): Promise<SourceManga> {
    const $ = cheerio.load(await this.get(`${DOMAIN}/comic/${mangaId}`))

    const title =
      $('h1').first().text().trim() ||
      mangaId.replace(/-/g, ' ')

    const image =
      $('img').filter((_, el) => {
        const src = $(el).attr('src') ?? ''
        const alt = $(el).attr('alt') ?? ''
        return /cover|thumbnail/i.test(src) || /cover/i.test(alt)
      }).first().attr('src') ??
      $('img').first().attr('src') ??
      ''

    const description =
      $('meta[name="description"]').attr('content') ??
      $('.summary').first().text().trim() ??
      ''

    return App.createSourceManga({
      id: mangaId,
      mangaInfo: App.createMangaInfo({
        titles: [title],
        image,
        desc: description,
        status: 'ONGOING',
        rating: 0,
        author: '',
        tags: [],
        hentai: false,
      }),
    })
  }

  async getChapters(mangaId: string): Promise<Chapter[]> {
    const $ = cheerio.load(await this.get(`${DOMAIN}/comic/${mangaId}`))
    const chapters: Chapter[] = []

    $('a[href*="/comic/"]').each((_, el) => {
      const a = $(el)
      const href = a.attr('href') ?? ''
      const match = href.match(/\/comic\/([^/]+)\/([^/?#]+)\/?$/)

      if (!match || match[1] !== mangaId) return

      const issueId = match[2]
      const id = `${mangaId}/${issueId}`

      if (chapters.some((x) => x.id === id)) return

      const label = a.text().replace(/\s+/g, ' ').trim()
      const numeric = issueId.match(/^\d+$/)

      chapters.push(App.createChapter({
        id,
        chapNum: numeric ? Number(issueId) : 0,
        name: label || `Issue #${issueId}`,
        volume: 0,
        time: new Date(),
        langCode: '🇬🇧',
      }))
    })

    return chapters
  }

  async getChapterDetails(
    mangaId: string,
    chapterId: string,
  ): Promise<ChapterDetails> {
    const $ = cheerio.load(await this.get(`${DOMAIN}/comic/${chapterId}`))
    const pages: string[] = []

    $('img').each((_, el) => {
      const src =
        $(el).attr('src') ??
        $(el).attr('data-src') ??
        ''

      if (
        /cdn\.readcomicsonline\.lol\/pages\//i.test(src) ||
        /\/pages\/[^/]+\/[^/]+\/p\d+\./i.test(src)
      ) {
        pages.push(src)
      }
    })

    return App.createChapterDetails({
      id: chapterId,
      mangaId,
      pages: [...new Set(pages)],
    })
  }

  getMangaShareUrl(mangaId: string): string {
    return `${DOMAIN}/comic/${mangaId}`
  }
}
