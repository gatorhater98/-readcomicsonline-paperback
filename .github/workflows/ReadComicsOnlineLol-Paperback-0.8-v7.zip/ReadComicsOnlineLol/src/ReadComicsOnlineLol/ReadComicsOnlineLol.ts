import {
  Chapter,
  ChapterDetails,
  ChapterProviding,
  ContentRating,
  MangaProviding,
  PagedResults,
  SearchRequest,
  SearchResultItem,
  SearchResultsProviding,
  Source,
  SourceInfo,
  SourceIntents,
  SourceManga,
  TagSection,
} from '@paperback/types'
import * as cheerio from 'cheerio'

const BASE_URL = 'https://readcomicsonline.lol'
const CDN_HOST = 'cdn.readcomicsonline.lol'

export const ReadComicsOnlineLolInfo: SourceInfo = {
  version: '0.7',
  name: 'ReadComicsOnline.lol',
  description: 'Experimental Western comics source',
  author: 'gatorhater98',
  authorWebsite: 'https://github.com/gatorhater98',
  icon: 'icon.png',
  contentRating: ContentRating.MATURE,
  websiteBaseURL: BASE_URL,
  intents: SourceIntents.MANGA_CHAPTERS,
  sourceTags: [],
}

export class ReadComicsOnlineLol extends Source implements SearchResultsProviding, MangaProviding, ChapterProviding {
  private async fetchText(url: string): Promise<string> {
    const request = App.createRequest({
      url,
      method: 'GET',
      headers: {
        Accept: 'text/html,application/xhtml+xml',
        Referer: `${BASE_URL}/`,
      },
    })

    const response = await this.requestManager.schedule(request, 1)
    return response.data
  }

  private absoluteUrl(url: string): string {
    if (!url) return ''
    if (url.startsWith('http://') || url.startsWith('https://')) return url
    if (url.startsWith('//')) return `https:${url}`
    return `${BASE_URL}${url.startsWith('/') ? '' : '/'}${url}`
  }

  private comicIdFromHref(href: string): string {
    const match = href.match(/\/comic\/([^/?#]+)/i)
    return match?.[1] ?? ''
  }

  private cleanText(value: string): string {
    return value.replace(/\s+/g, ' ').trim()
  }

  async getSearchResults(query: SearchRequest, metadata: any): Promise<PagedResults> {
    const page = metadata?.page ?? 1
    const title = (query.title ?? '').trim()
    if (!title) {
      return { results: [], metadata: undefined }
    }

    const url = `${BASE_URL}/search?q=${encodeURIComponent(title)}${page > 1 ? `&page=${page}` : ''}`
    const html = await this.fetchText(url)
    const $ = cheerio.load(html)
    const results: SearchResultItem[] = []
    const seen = new Set<string>()

    $('a[href*="/comic/"]').each((_, element) => {
      const link = $(element)
      const href = link.attr('href') ?? ''
      const mangaId = this.comicIdFromHref(href)
      if (!mangaId || seen.has(mangaId)) return

      const image = link.find('img').first()
      const imageUrl = this.absoluteUrl(image.attr('src') ?? image.attr('data-src') ?? '')
      const linkText = this.cleanText(link.text())
      const alt = this.cleanText(image.attr('alt') ?? '')
      const titleText = alt || linkText

      if (!titleText) return
      seen.add(mangaId)
      results.push({
        mangaId,
        title: titleText,
        imageUrl,
      })
    })

    const hasNextPage = $('a[rel="next"]').length > 0 ||
      $('a').filter((_, el) => /next/i.test($(el).text().trim())).length > 0

    return {
      results,
      metadata: hasNextPage ? { page: page + 1 } : undefined,
    }
  }

  async getMangaDetails(mangaId: string): Promise<SourceManga> {
    const html = await this.fetchText(`${BASE_URL}/comic/${mangaId}`)
    const $ = cheerio.load(html)

    const title = this.cleanText($('h1').first().text()) || mangaId
    const cover = this.absoluteUrl(
      $('img').filter((_, el) => {
        const src = $(el).attr('src') ?? ''
        const alt = $(el).attr('alt') ?? ''
        return src.includes(CDN_HOST) && /cover|comic/i.test(`${src} ${alt}`)
      }).first().attr('src') ?? $('img').first().attr('src') ?? '',
    )

    const summaryHeading = $('h2').filter((_, el) => /summary|description/i.test($(el).text())).first()
    const summary = summaryHeading.length
      ? this.cleanText(summaryHeading.nextAll('p').first().text())
      : this.cleanText($('p').filter((_, el) => /read .* comic online free/i.test($(el).text())).first().text())

    const writer = this.cleanText(
      $('body').text().match(/Writer\s+([^\n]+?)(?:Artist|Views|Issues|Updated)/i)?.[1] ?? '',
    )
    const artist = this.cleanText(
      $('body').text().match(/Artist\s+([^\n]+?)(?:Views|Issues|Updated)/i)?.[1] ?? '',
    )

    const tags: TagSection[] = []
    const genres: string[] = []
    $('a[href*="/genre/"]').each((_, el) => {
      const value = this.cleanText($(el).text())
      if (value && !genres.includes(value)) genres.push(value)
    })
    if (genres.length) {
      tags.push({
        id: 'genres',
        title: 'Genres',
        tags: genres.map(value => ({
          id: value.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
          title: value,
        })),
      })
    }

    const bodyText = this.cleanText($('body').text())
    const status = /\bongoing\b/i.test(bodyText)
      ? 'ONGOING'
      : /\bcompleted\b/i.test(bodyText)
        ? 'COMPLETED'
        : 'UNKNOWN'

    return {
      mangaId,
      mangaInfo: {
        primaryTitle: title,
        secondaryTitles: [],
        thumbnailUrl: cover,
        synopsis: summary,
        author: writer,
        artist,
        rating: 0,
        contentRating: ContentRating.MATURE,
        status,
        tagGroups: tags,
      },
    }
  }

  async getChapters(sourceManga: SourceManga): Promise<Chapter[]> {
    const html = await this.fetchText(`${BASE_URL}/comic/${sourceManga.mangaId}`)
    const $ = cheerio.load(html)
    const chapters: Chapter[] = []
    const seen = new Set<string>()

    $('a[href*="/comic/"]').each((_, element) => {
      const link = $(element)
      const href = link.attr('href') ?? ''
      const match = href.match(/\/comic\/([^/?#]+)\/([^/?#]+)/i)
      if (!match || match[1] !== sourceManga.mangaId) return

      const chapterId = match[2]
      if (seen.has(chapterId)) return
      seen.add(chapterId)

      const text = this.cleanText(link.text())
      const title = text || `#${chapterId}`
      const numberMatch = title.match(/#?\s*(\d+(?:\.\d+)?)/)
      const chapNum = numberMatch ? parseFloat(numberMatch[1]) : 0

      const dateText = this.cleanText(link.find('time').attr('datetime') ?? link.find('time').text())
      const parsedDate = dateText ? new Date(dateText) : undefined

      chapters.push({
        chapterId,
        title,
        sourceManga,
        chapNum,
        volume: 0,
        langCode: 'en',
        publishDate: parsedDate && !isNaN(parsedDate.getTime()) ? parsedDate : undefined,
      })
    })

    return chapters.sort((a, b) => (a.chapNum ?? 0) - (b.chapNum ?? 0))
  }

  async getChapterDetails(chapter: Chapter): Promise<ChapterDetails> {
    const url = `${BASE_URL}/comic/${chapter.sourceManga.mangaId}/${chapter.chapterId}`
    const html = await this.fetchText(url)
    const $ = cheerio.load(html)
    const pages: string[] = []
    const seen = new Set<string>()

    $('img').each((_, element) => {
      const image = $(element)
      const src = image.attr('src') ?? image.attr('data-src') ?? image.attr('data-lazy-src') ?? ''
      const absolute = this.absoluteUrl(src)
      if (!absolute || !absolute.includes(CDN_HOST) || seen.has(absolute)) return
      seen.add(absolute)
      pages.push(absolute)
    })

    return {
      id: chapter.chapterId,
      mangaId: chapter.sourceManga.mangaId,
      pages,
    }
  }

  getMangaShareUrl(mangaId: string): string {
    return `${BASE_URL}/comic/${mangaId}`
  }
}
